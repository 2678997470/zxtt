from flask import Flask, request, session, redirect, url_for, render_template
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = 'your secret key'  # 用于加密 session

@app.route('/handle_file', methods=['POST'])
def handle_file():
    # 获取用户名
    username = session.get('username')
    if not username:
        return redirect(url_for('home'))

    filename = request.form.get('filename')
    content = request.form.get('content')

    # 检查文件名是否在允许的范围内
    if filename not in ['s1', 's2', 's3', 's4', 's5', 's6', 's7', 's8']:
        return 'Invalid filename', 400

    # 将数据写入到文件中
    os.makedirs(f'user_files/{username}', exist_ok=True)
    with open(f'user_files/{username}/{filename}.txt', 'w') as f:
        f.write(content)

    return 'File written successfully'


@app.route('/read_file', methods=['POST'])
def read_file():
    # 获取用户名
    username = session.get('username')
    if not username:
        return redirect(url_for('home'))

    filename = request.form.get('filename')

    # 检查文件名是否在允许的范围内
    if filename not in ['s1', 's2', 's3', 's4', 's5', 's6', 's7', 's8']:
        return 'Invalid filename', 400

    # 从文件中读取数据
    try:
        with open(f'user_files/{username}/{filename}.txt', 'r') as f:
            content = f.read()
    except FileNotFoundError:
        return 'File not found', 400

    return content




@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        action = request.form.get('action')
        username = request.form.get('username')
        password = request.form.get('password')

        if action == 'register':
            # 在这里将用户的用户名和密码保存到文件中
            password_hash = generate_password_hash(password)
            with open('users.txt', 'a') as f:
                f.write(f'{username},{password_hash}\n')
            
            # 创建用户文件夹
            os.makedirs(f'user_files/{username}', exist_ok=True)

            return 'Registered successfully!'

        elif action == 'login':
            # 在这里验证用户的用户名和密码
            with open('users.txt', 'r') as f:
                users = f.readlines()
            for user in users:
                user_name, user_password = user.strip().split(',')
                if username == user_name and check_password_hash(user_password, password):
                    # 如果验证成功，将用户的信息存储在 session 中
                    session['username'] = username
                    return redirect(url_for('welcome'))

    return render_template('home.html')

@app.route('/welcome')
def welcome():
    # 检查用户是否已登录
    if 'username' not in session:
        return redirect(url_for('home'))

    return render_template('welcome.html', username=session['username'])

@app.route('/logout')
def logout():
    # 删除 session 中的用户名来登出用户
    session.pop('username', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
