import hashlib
import os
import requests
from flask import Flask, render_template, request

app = Flask(__name__,template_folder='templates')


# template_dir = os.path.abspath('index.html')
# app.template_folder = template_dir
@app.route('/', methods=['GET', 'POST'])
def save_game():
    if request.method == 'POST':
        GameUserName = request.form['username']
        GamePassWord = request.form['password']
        gameid = "1000" + request.form['gameid']
        date = request.form['data']
        title = request.form['title']
        index = request.form['index']

        molianps = {
            'loginFrom': 'uframe',
            'layoutSelfAdapting': 'true',
            'layout': 'vertical',
            'mainDivId': 'embed_login_div',
            'includeFcmInfo': 'false',
            'level': '0',
            'regLevel': '0',
            'password': GamePassWord,
            'username': GameUserName
        }
        drpost = requests.post("https://ptlogin.4399.com/ptlogin/login.do?v=1", data=molianps)

        uid = requests.get("http://cz.4399.com/get_role_info.php?ac=cuid&uname=" + GameUserName)
        uid = uid.text

        gamekey = gameid + "LPislKLodlLKKOSNlSDOAADLKADJAOADALAklsd" + gameid
        ssr = gamekey
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        ssr = hl.hexdigest()
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        gamekey = hl.hexdigest()
        gamekey = gamekey[4:20]

        print("游戏id" + gameid + "游戏存档位置" + index)

        verify = "SDALPlsldlnSLWPElsdslSE" + index + gamekey + date + title + uid + gameid + "PKslsO"
        ssr = verify
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        ssr = hl.hexdigest()
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        ssr = hl.hexdigest()
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        verify = hl.hexdigest()

        jbbl = "SDALPlsldlnSLWPElsdslSE" + gamekey + uid + gameid + "PKslsO"
        ssr = jbbl
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        ssr = hl.hexdigest()
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        ssr = hl.hexdigest()
        hl = hashlib.md5()
        hl.update(ssr.encode("utf-8"))
        jbbl = hl.hexdigest()
        molianps = {
            "uid": uid,
            "gameid": gameid,
            "gamekey": gamekey,
            "verify": jbbl
        }
        session = "https://save.api.4399.com/?ac=get_session"
        session = requests.post(session, molianps)
        print("这里是session：" + session.text)

        data = {
            'session': '',
            'gamekey': gamekey,
            'verify': verify,
            'data': date,
            'gameid': gameid,
            'token': '',
            'title': title,
            'refer': 'https://sda.4399.com/4399swf/upload_swf/ftp7/hanbao/20120107/6/y3v3710.htm',
            'index': index,
            'uid': uid
        }
        print(data)
        zr = requests.post("https://save.api.4399.com/?ac=save", data=data, cookies=drpost.cookies)
        print(zr.text)
        if zr.text == "1":
            result = "save yes"
        else:
            result = zr.text
            
        return render_template('index.html', result=result)
    else:
        return render_template('index.html')
app.debug = True


if __name__ == '__main__':
    with app.app_context():
        # template_dir = os.path.abspath(os.getcwd())
        # app.template_folder = template_dir
        app.run('0.0.0.0', 8888)
